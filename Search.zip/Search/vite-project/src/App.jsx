import React, { useState } from "react"

function App() {

  const [selectedCategory, setSelectedCategory] = useState('all')
  const [search, setSearch] = useState('')

  const items = ['red', 'blue', 'green']

  const handleSearch = (inputValue) => {
    setSearch(inputValue.target.value)
  }

  const handleCategoryChange = (event) => {
    setSelectedCategory(event.target.value)
  }

  const filteredItems = items.filter(item => selectedCategory === 'all' || item === selectedCategory)


  return (
    <>
    <div>
      <div className="categories-container">
        <select onChange={handleCategoryChange}>
          <option value='all'>Все</option>
          <option value='red'>red</option>
          <option value='blue'>blue</option>
          <option value='green'>green</option>
        </select>

        <div className="categories">
          {
            filteredItems.map((item) => (
              <li>{item}</li>
            ))
          }
        </div>
      </div>

      <input onChange={handleSearch} placeholder="Поиск"></input>
      <div className="search">
      {
        items.filter((item) =>
          item.toLowerCase().includes(search.toLowerCase()))
      }
      </div>
    </div>
    </>
  )
}

export default App
